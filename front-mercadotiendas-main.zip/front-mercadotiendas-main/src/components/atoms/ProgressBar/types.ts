export interface ProgressBarProps {
  progress?: number; // 0 to 100
  height?: string;
  backgroundColor?: string;
  progressColor?: string;
  className?: string;
}
