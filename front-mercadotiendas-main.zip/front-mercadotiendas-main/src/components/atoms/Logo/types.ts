export interface LogoProps {
  size?: number;
  color?: string;
  className?: string;
}
