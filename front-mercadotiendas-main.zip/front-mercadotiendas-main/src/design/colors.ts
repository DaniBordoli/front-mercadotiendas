export const colors = {
    primaryRed: '#FF4F41',
    darkGray: '#1C1C1E',
    mediumGray: '#666666',
    accentTeal: '#00A699',
    lightGray: '#E5E5E7',
    ultraLightGray: '#F8F8F8',
    baseTextColor: '#000000', 
    baseBackgroundColor: '#FFFFFF', 
};
